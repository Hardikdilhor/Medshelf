-- Run this once in Supabase SQL Editor for manual UPI payment review.
create table if not exists public.manual_payment_submissions (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.orders(id) on delete cascade,
  utr text not null,
  claimed_paid_at timestamptz not null,
  screenshot_path text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  submitted_at timestamptz not null default now(),
  reviewed_at timestamptz
);
create index if not exists manual_payment_status_idx on public.manual_payment_submissions(status,submitted_at desc);
alter table public.manual_payment_submissions enable row level security;

-- Private bucket: screenshots are not public. The backend signs short-lived review links.
insert into storage.buckets (id,name,public)
values ('manual-payment-screenshots','manual-payment-screenshots',false)
on conflict (id) do nothing;
